A Pen created at CodePen.io. You can find this one at http://codepen.io/endodoug/pen/ecBkL.

 html and css loader form kevin martin